package model;

public class Entidade {

}
