package model;

import java.awt.Rectangle;
import java.util.ArrayList;

public class Player{
	
	private String nome;
	private int vida;
	private int dano;
	private Sprite sprite=null;
	private ArrayList<Item>items;
	private int contadorAtaque, contadorFlecha;
	private int lado=0;
	private int ladoFlecha=2;

	public Player(String nome) {
		this.nome = nome;
		vida=200;
		dano = 10;
		contadorAtaque=0;
		contadorFlecha=0;
		items = new ArrayList<>();
	}
	
	public void atacar(Inimigo inimigo) {
		inimigo.setVida(inimigo.getVida()-dano);
		
	}
	
	public Rectangle interagir() {
		Rectangle rect = new Rectangle(sprite.posX-1, sprite.posY-1, sprite.width+2, sprite.height+2);
		return rect;
	}
	
	public void addItem(Item item) {
		items.add(item);
	}
	
	public ArrayList<Item> getItems() {
		return items;
	}

	public void setItems(ArrayList<Item> items) {
		this.items = items;
	}

	public String getNome() {
		return nome;
	}


	public int getVida() {
		return vida;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public void setVida(int vida) {
		if(vida <=200 && vida >= 0)
			this.vida = vida;
		if (vida > 200)
			this.vida =200;
	
		if (vida <0 )
			this.vida =0;
	}

	public int getDano() {
		return dano;
	}


	public void setDano(int dano) {
		this.dano = dano;
	}
	
	public Sprite getSprite() {
		return sprite;
	}

	public void setSprite(Sprite sprite) {
		this.sprite = sprite;
	}

	public int getContadorAtaque() {
		return contadorAtaque;
	}

	public void setContadorAtaque(int contadorAtaque) {
		this.contadorAtaque = contadorAtaque;
	}

	public int getContadorFlecha() {
		return contadorFlecha;
	}

	public void setContadorFlecha(int contadorFlecha) {
		this.contadorFlecha = contadorFlecha;
	}

	public int getLado() {
		return lado;
	}

	public void setLado(int lado) {
		this.lado = lado;
	}

	public int getLadoFlecha() {
		return ladoFlecha;
	}

	public void setLadoFlecha(int ladoFlecha) {
		this.ladoFlecha = ladoFlecha;
	}
	
}
