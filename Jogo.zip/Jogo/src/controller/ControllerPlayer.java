package controller;

import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import model.Flecha;
import model.Player;
import view.TelaGame;

public class ControllerPlayer extends KeyAdapter{
	
	private Player player, player2;
	private TelaGame telagame;
	private static int velocidade=1;
	private int up, down, left, right, up2, down2, left2, right2;
	
	public ControllerPlayer(TelaGame telagame) {
		this.telagame = telagame;
		this.player = telagame.getPlayer1();
		this.player2 = telagame.getPlayer2();
		telagame.addKeyListener(new TAdapter());
	}
	
	public class TAdapter extends KeyAdapter{
		
		public void keyPressed(KeyEvent e) {
			
			if (e.getKeyCode()==KeyEvent.VK_W){
				player.setLadoFlecha(3);
				Rectangle test = new Rectangle(player.getSprite().posX, player.getSprite().posY-4, player.getSprite().width, player.getSprite().height);
				if (telagame.getGame().colisao(player.getSprite().posX, player.getSprite().posY-4) && telagame.getGame().colisaoRectangle(test, player.getSprite())) {
					if (telagame.getGame().colisao(player.getSprite().posX+31, player.getSprite().posY-4)){
						player.getSprite().posY -= 4;
						player.getSprite().setRect(new Rectangle(player.getSprite().posX, player.getSprite().posY, player.getSprite().width, player.getSprite().height));
					}
				}
				switch (up) {
				case 0:
					player.getSprite().aparencia=0+player.getLado();
					break;
				case 1:
					player.getSprite().aparencia=2+player.getLado();
					break;
				case 2:
					player.getSprite().aparencia=4+player.getLado();
					break;
				case 3:
					player.getSprite().aparencia=6+player.getLado();
	
					break;
				}
				if (up==3) up=0;
				else up++;
				test=null;
				
			}
			if (e.getKeyCode()==KeyEvent.VK_S){
				player.setLadoFlecha(1);;
				Rectangle test = new Rectangle(player.getSprite().posX, player.getSprite().posY+4, player.getSprite().width, player.getSprite().height);
				if (telagame.getGame().colisao(player.getSprite().posX, player.getSprite().posY+35) && telagame.getGame().colisaoRectangle(test, player.getSprite())) {
					if (telagame.getGame().colisao(player.getSprite().posX+31, player.getSprite().posY+35) ){
						player.getSprite().posY += 4;
						player.getSprite().setRect(new Rectangle(player.getSprite().posX, player.getSprite().posY, player.getSprite().width, player.getSprite().height));
					}
				}
				switch (down) {
				case 0:
					player.getSprite().aparencia=0+player.getLado();
					break;
				case 1:
					player.getSprite().aparencia=2+player.getLado();
					break;
				case 2:
					player.getSprite().aparencia=4+player.getLado();
					break;
				case 3:
					player.getSprite().aparencia=6+player.getLado();
	
					break;
				}
				if (down==3) down=0;
				else down++;
				test=null;
				
			}
			if (e.getKeyCode()==KeyEvent.VK_A){
				player.setLadoFlecha(0);
				player.setLado(1);
				Rectangle test = new Rectangle(player.getSprite().posX-4, player.getSprite().posY, player.getSprite().width, player.getSprite().height);
				if (telagame.getGame().colisao(player.getSprite().posX-4, player.getSprite().posY) && telagame.getGame().colisaoRectangle(test,player.getSprite())) {
					if (telagame.getGame().colisao(player.getSprite().posX-4, player.getSprite().posY+31) ){
						player.getSprite().posX -= 4;
						player.getSprite().setRect(new Rectangle(player.getSprite().posX, player.getSprite().posY, player.getSprite().width, player.getSprite().height));
					}
				}
				switch (left) {
				case 0:
					player.getSprite().aparencia=0+player.getLado();
					break;
				case 1:
					player.getSprite().aparencia=2+player.getLado();
					break;
				case 2:
					player.getSprite().aparencia=4+player.getLado();
					break;
				case 3:
					player.getSprite().aparencia=6+player.getLado();
	
					break;
				}
				if (left==3) left=0;
				else left++;
				test=null;
				
			}
			if (e.getKeyCode()==KeyEvent.VK_D){
				player.setLadoFlecha(2);
				player.setLado(0);
				Rectangle test = new Rectangle(player.getSprite().posX+4, player.getSprite().posY, player.getSprite().width, player.getSprite().height);
				if (telagame.getGame().colisao(player.getSprite().posX+35, player.getSprite().posY) && telagame.getGame().colisaoRectangle(test,player.getSprite())) {
					if (telagame.getGame().colisao(player.getSprite().posX+35, player.getSprite().posY+31) ){
						player.getSprite().posX += 4;
						player.getSprite().setRect(new Rectangle(player.getSprite().posX, player.getSprite().posY, player.getSprite().width, player.getSprite().height));
					}
				}
				switch (right) {
				case 0:
					player.getSprite().aparencia=0+player.getLado();
					break;
				case 1:
					player.getSprite().aparencia=2+player.getLado();
					break;
				case 2:
					player.getSprite().aparencia=4+player.getLado();
					break;
				case 3:
					player.getSprite().aparencia=6+player.getLado();
	
					break;
				}
				if (right==3) right=0;
				else right++;
				test=null;
			}
			
			if (e.getKeyCode()==KeyEvent.VK_UP && player2!=null){
				player2.setLadoFlecha(3);
				Rectangle test = new Rectangle(player2.getSprite().posX, player2.getSprite().posY-4, player2.getSprite().width, player2.getSprite().height);
				if (telagame.getGame().colisao(player2.getSprite().posX, player2.getSprite().posY-4) && telagame.getGame().colisaoRectangle(test, player2.getSprite())) {
					if (telagame.getGame().colisao(player2.getSprite().posX+31, player2.getSprite().posY-4)){
						player2.getSprite().posY -= 4;
						player2.getSprite().setRect(new Rectangle(player2.getSprite().posX, player2.getSprite().posY, player2.getSprite().width, player2.getSprite().height));
					}
				}
				switch (up2) {
				case 0:
					player2.getSprite().aparencia=0+player2.getLado();
					break;
				case 1:
					player2.getSprite().aparencia=2+player2.getLado();
					break;
				case 2:
					player2.getSprite().aparencia=4+player2.getLado();
					break;
				case 3:
					player2.getSprite().aparencia=6+player2.getLado();
	
					break;
				}
				if (up2==3) up2=0;
				else up2++;
				test=null;
				
			}
			if (e.getKeyCode()==KeyEvent.VK_DOWN && player2!=null){
				player2.setLadoFlecha(1);
				Rectangle test = new Rectangle(player2.getSprite().posX, player2.getSprite().posY+4, player2.getSprite().width, player2.getSprite().height);
				if (telagame.getGame().colisao(player2.getSprite().posX, player2.getSprite().posY+35) && telagame.getGame().colisaoRectangle(test, player2.getSprite())) {
					if (telagame.getGame().colisao(player2.getSprite().posX+31, player2.getSprite().posY+35) ){
						player2.getSprite().posY += 4;
						player2.getSprite().setRect(new Rectangle(player2.getSprite().posX, player2.getSprite().posY, player2.getSprite().width, player2.getSprite().height));
					}
				}
				switch (down2) {
				case 0:
					player2.getSprite().aparencia=0+player2.getLado();
					break;
				case 1:
					player2.getSprite().aparencia=2+player2.getLado();
					break;
				case 2:
					player2.getSprite().aparencia=4+player2.getLado();
					break;
				case 3:
					player2.getSprite().aparencia=6+player2.getLado();
	
					break;
				}
				if (down2==3) down2=0;
				else down2++;
				test=null;
				
			}
			if (e.getKeyCode()==KeyEvent.VK_LEFT && player2!=null){
				player2.setLadoFlecha(0);
				player2.setLado(1);
				Rectangle test = new Rectangle(player2.getSprite().posX-4, player2.getSprite().posY, player2.getSprite().width, player2.getSprite().height);
				if (telagame.getGame().colisao(player2.getSprite().posX-4, player2.getSprite().posY) && telagame.getGame().colisaoRectangle(test,player2.getSprite())) {
					if (telagame.getGame().colisao(player2.getSprite().posX-4, player2.getSprite().posY+31) ){
						player2.getSprite().posX -= 4;
						player2.getSprite().setRect(new Rectangle(player2.getSprite().posX, player2.getSprite().posY, player2.getSprite().width, player2.getSprite().height));
					}
				}
				switch (left2) {
				case 0:
					player2.getSprite().aparencia=0+player2.getLado();
					break;
				case 1:
					player2.getSprite().aparencia=2+player2.getLado();
					break;
				case 2:
					player2.getSprite().aparencia=4+player2.getLado();
					break;
				case 3:
					player2.getSprite().aparencia=6+player2.getLado();
	
					break;
				}
				if (left2==3) left2=0;
				else left2++;
				test=null;
				
			}
			if (e.getKeyCode()==KeyEvent.VK_RIGHT && player2!=null){
				player2.setLadoFlecha(2);
				player2.setLado(0);
				Rectangle test = new Rectangle(player2.getSprite().posX+4, player2.getSprite().posY, player2.getSprite().width, player2.getSprite().height);
				if (telagame.getGame().colisao(player2.getSprite().posX+35, player2.getSprite().posY) && telagame.getGame().colisaoRectangle(test,player2.getSprite())) {
					if (telagame.getGame().colisao(player2.getSprite().posX+35, player2.getSprite().posY+31) ){
						player2.getSprite().posX += 4;
						player2.getSprite().setRect(new Rectangle(player2.getSprite().posX, player2.getSprite().posY, player2.getSprite().width, player2.getSprite().height));
					}
				}
				switch (right2) {
				case 0:
					player2.getSprite().aparencia=0+player2.getLado();
					break;
				case 1:
					player2.getSprite().aparencia=2+player2.getLado();
					break;
				case 2:
					player2.getSprite().aparencia=4+player2.getLado();
					break;
				case 3:
					player2.getSprite().aparencia=6+player2.getLado();
	
					break;
				}
				if (right2==3) right2=0;
				else right2++;
				test=null;
			}
		
		}
			
			
		public void keyReleased(KeyEvent e) {
			 
			if (e.getKeyCode()== KeyEvent.VK_SPACE) {
				if (player.getContadorFlecha() == 0) {
					Flecha f = new Flecha(player.getLadoFlecha(), player.getSprite().posX, player.getSprite().posY);
					ControllerFlecha cf = new ControllerFlecha(f, telagame);
					telagame.getFlechas().add(f);
					new Thread(cf).start();
					player.setContadorFlecha(40);
				}
			}
			
			if (e.getKeyCode()== KeyEvent.VK_E) {
				telagame.getGame().verificarSairMapa(player, telagame.getMapaatual().getSair());
				telagame.getGame().verificarAbrirPorta(player);
				if (telagame.isEhMapaSala())telagame.getGame().verificarEntrarMapa(player);
				
			}
			
			if (e.getKeyCode()== KeyEvent.VK_ENTER) {
				if (player.getLado()==0) {
					Rectangle test = new Rectangle(player.getSprite().posX+15, player.getSprite().posY-4, (player.getSprite().width/2)+4, player.getSprite().height+8);
					if (telagame.getGame().colisaoInimigo(test)==false && player.getContadorAtaque()==0) {
						telagame.getGame().atacarInimigo(player, test);
						player.setContadorAtaque(20);
					}
				}
				
				if (player.getLado()==1) {
					Rectangle test = new Rectangle(player.getSprite().posX-4, player.getSprite().posY-4, (player.getSprite().width/2)+4, player.getSprite().height+8);
					if (telagame.getGame().colisaoInimigo(test)==false && player.getContadorAtaque()==0) {
						telagame.getGame().atacarInimigo(player, test);
						player.setContadorAtaque(20);
					}
				}
			}
			
			
			
			if (e.getKeyCode()== KeyEvent.VK_NUMPAD2 && player2!=null) {
				if (player2.getContadorFlecha() ==0) {
					Flecha f = new Flecha(player2.getLadoFlecha(), player2.getSprite().posX, player2.getSprite().posY);
					ControllerFlecha cf = new ControllerFlecha(f, telagame);
					telagame.getFlechas().add(f);
					new Thread(cf).start();
					player2.setContadorFlecha(40);
				}
			}
			
			if (e.getKeyCode()== KeyEvent.VK_NUMPAD3 && player2!=null) {
				telagame.getGame().verificarSairMapa(player2, telagame.getMapaatual().getSair());
				telagame.getGame().verificarAbrirPorta(player2);
				if (telagame.isEhMapaSala())telagame.getGame().verificarEntrarMapa(player2);
				
			}
			
			if (e.getKeyCode()== KeyEvent.VK_NUMPAD1 && player2!=null) {
				if (player2.getLado()==0) {
					Rectangle test = new Rectangle(player2.getSprite().posX+15, player2.getSprite().posY-4, (player2.getSprite().width/2)+4, player2.getSprite().height+8);
					if (telagame.getGame().colisaoInimigo(test)==false && player2.getContadorAtaque()==0) {
						telagame.getGame().atacarInimigo(player2, test);
						player2.setContadorAtaque(20);
					}
				}
				
				if (player2.getLado()==1) {
					Rectangle test = new Rectangle(player2.getSprite().posX-4, player2.getSprite().posY-4, (player2.getSprite().width/2)+4, player2.getSprite().height+8);
					if (telagame.getGame().colisaoInimigo(test)==false && player2.getContadorAtaque()==0) {
						telagame.getGame().atacarInimigo(player2, test);
						player2.setContadorAtaque(20);
					}
				}
			}
			
			
		}
		
	}
	
	
	public static int getVelocidade() {
		return velocidade;
	}

	public static void setVelocidade(int velocidade) {
		ControllerPlayer.velocidade = velocidade;
	}
	
}
